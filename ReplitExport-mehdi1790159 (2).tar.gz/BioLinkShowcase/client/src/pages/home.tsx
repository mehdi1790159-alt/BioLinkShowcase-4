import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { 
  Instagram, 
  Twitter, 
  Linkedin, 
  Github, 
  Youtube,
  ExternalLink,
  Mail
} from "lucide-react";
import { SiTiktok } from "react-icons/si";
import { Card } from "@/components/ui/card";

interface Profile {
  id: string;
  name: string;
  title: string;
  bio: string;
  profileImageUrl: string;
  email: string;
  followers: number;
  following: number;
  posts: number;
}

interface SocialLink {
  id: string;
  profileId: string;
  platform: string;
  url: string;
  username: string;
  isVisible: string;
}

interface ProfileData {
  profile: Profile;
  socialLinks: SocialLink[];
}

const platformConfig = {
  instagram: {
    icon: Instagram,
    name: "Instagram",
    className: "instagram-gradient",
  },
  twitter: {
    icon: Twitter,
    name: "Twitter",
    className: "twitter-bg",
  },
  linkedin: {
    icon: Linkedin,
    name: "LinkedIn", 
    className: "linkedin-bg",
  },
  github: {
    icon: Github,
    name: "GitHub",
    className: "github-bg",
  },
  tiktok: {
    icon: SiTiktok,
    name: "TikTok",
    className: "tiktok-gradient",
  },
  youtube: {
    icon: Youtube,
    name: "YouTube",
    className: "youtube-bg",
  },
};

const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
};

export default function Home() {
  const { data, isLoading, error } = useQuery<ProfileData>({
    queryKey: ['/api/profile'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center">
        <div className="text-white text-lg" data-testid="loading-message">Loading...</div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center">
        <div className="text-white text-lg" data-testid="error-message">
          Failed to load profile data
        </div>
      </div>
    );
  }

  const { profile, socialLinks } = data;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Profile Section */}
          <motion.div variants={itemVariants} className="text-center mb-8">
            {/* Profile Image with Gradient Border */}
            <div className="gradient-border inline-block mb-4">
              <img
                src={profile.profileImageUrl}
                alt={`${profile.name} Profile Picture`}
                className="profile-image w-24 h-24 rounded-full object-cover"
                data-testid="img-profile"
              />
            </div>
            
            {/* Profile Info */}
            <h1 className="text-2xl font-bold text-white mb-2" data-testid="text-name">
              {profile.name}
            </h1>
            <p className="text-gray-200 text-sm mb-1" data-testid="text-title">
              {profile.title}
            </p>
            <p className="text-gray-300 text-xs mb-6 px-4" data-testid="text-bio">
              {profile.bio}
            </p>
            
            {/* Stats */}
            <div className="flex justify-center space-x-6 mb-6">
              <div className="text-center">
                <div className="text-white font-semibold" data-testid="text-followers">
                  {formatNumber(profile.followers)}
                </div>
                <div className="text-gray-300 text-xs">Followers</div>
              </div>
              <div className="text-center">
                <div className="text-white font-semibold" data-testid="text-following">
                  {formatNumber(profile.following)}
                </div>
                <div className="text-gray-300 text-xs">Following</div>
              </div>
              <div className="text-center">
                <div className="text-white font-semibold" data-testid="text-posts">
                  {formatNumber(profile.posts)}
                </div>
                <div className="text-gray-300 text-xs">Posts</div>
              </div>
            </div>
          </motion.div>

          {/* Social Links Grid */}
          <div className="space-y-4">
            {socialLinks.map((link, index) => {
              const config = platformConfig[link.platform as keyof typeof platformConfig];
              if (!config) return null;

              const IconComponent = config.icon;

              return (
                <motion.div
                  key={link.id}
                  variants={itemVariants}
                  custom={index}
                >
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="social-link block w-full bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg hover:shadow-xl"
                    data-testid={`link-${link.platform}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`${config.className} w-12 h-12 rounded-xl flex items-center justify-center`}>
                        <IconComponent className="text-white text-xl w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800" data-testid={`text-${link.platform}-name`}>
                          {config.name}
                        </h3>
                        <p className="text-gray-600 text-sm" data-testid={`text-${link.platform}-username`}>
                          {link.username}
                        </p>
                      </div>
                      <ExternalLink className="text-gray-400 w-4 h-4" />
                    </div>
                  </a>
                </motion.div>
              );
            })}
          </div>

          {/* Contact Section */}
          <motion.div variants={itemVariants} className="mt-8 text-center">
            <Card className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border-0">
              <h3 className="font-semibold text-gray-800 mb-2" data-testid="text-contact-title">
                Get in Touch
              </h3>
              <p className="text-gray-600 text-sm mb-3" data-testid="text-contact-description">
                Have a project in mind? Let's collaborate!
              </p>
              <a
                href={`mailto:${profile.email}`}
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2 rounded-xl font-medium hover:from-purple-600 hover:to-pink-600 transition-all duration-300"
                data-testid="button-email"
              >
                <Mail className="w-4 h-4" />
                <span>Send Email</span>
              </a>
            </Card>
          </motion.div>

          {/* Footer */}
          <motion.div variants={itemVariants} className="mt-8 text-center">
            <p className="text-white/70 text-xs" data-testid="text-copyright">
              © 2024 {profile.name}. Made with ❤️
            </p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
