import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get default profile with social links
  app.get("/api/profile", async (req, res) => {
    try {
      const profile = await storage.getDefaultProfile();
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      const socialLinks = await storage.getSocialLinksByProfileId(profile.id);
      
      res.json({
        profile,
        socialLinks,
      });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get profile by ID
  app.get("/api/profile/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await storage.getProfile(id);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      const socialLinks = await storage.getSocialLinksByProfileId(profile.id);
      
      res.json({
        profile,
        socialLinks,
      });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
