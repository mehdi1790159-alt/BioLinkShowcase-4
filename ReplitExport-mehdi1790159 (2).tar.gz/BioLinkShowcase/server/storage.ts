import { type Profile, type InsertProfile, type SocialLink, type InsertSocialLink } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Profile operations
  getProfile(id: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  getDefaultProfile(): Promise<Profile | undefined>;
  
  // Social links operations
  getSocialLinksByProfileId(profileId: string): Promise<SocialLink[]>;
  createSocialLink(socialLink: InsertSocialLink): Promise<SocialLink>;
}

export class MemStorage implements IStorage {
  private profiles: Map<string, Profile>;
  private socialLinks: Map<string, SocialLink>;

  constructor() {
    this.profiles = new Map();
    this.socialLinks = new Map();
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    // Create default profile
    const defaultProfile: Profile = {
      id: "default-profile-id",
      name: "Alex Johnson",
      title: "Creative Designer & Developer",
      bio: "Passionate about creating beautiful digital experiences. Follow me on my creative journey! ✨",
      profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=300",
      email: "alex@example.com",
      followers: 12500,
      following: 892,
      posts: 156,
    };
    
    this.profiles.set(defaultProfile.id, defaultProfile);

    // Create default social links
    const defaultSocialLinks: SocialLink[] = [
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "instagram",
        url: "https://instagram.com/alexjohnson_creative",
        username: "@alexjohnson_creative",
        isVisible: "true",
      },
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "twitter",
        url: "https://twitter.com/alexjcreative",
        username: "@alexjcreative",
        isVisible: "true",
      },
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "linkedin",
        url: "https://linkedin.com/in/alexjohnson",
        username: "Alex Johnson",
        isVisible: "true",
      },
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "github",
        url: "https://github.com/alexjohnson-dev",
        username: "alexjohnson-dev",
        isVisible: "true",
      },
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "tiktok",
        url: "https://tiktok.com/@alexcreates",
        username: "@alexcreates",
        isVisible: "true",
      },
      {
        id: randomUUID(),
        profileId: defaultProfile.id,
        platform: "youtube",
        url: "https://youtube.com/c/alexjohnsoncreative",
        username: "Alex Johnson Creative",
        isVisible: "true",
      },
    ];

    defaultSocialLinks.forEach(link => {
      this.socialLinks.set(link.id, link);
    });
  }

  async getProfile(id: string): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = randomUUID();
    const profile: Profile = { 
      ...insertProfile, 
      id,
      followers: insertProfile.followers ?? 0,
      following: insertProfile.following ?? 0,
      posts: insertProfile.posts ?? 0,
    };
    this.profiles.set(id, profile);
    return profile;
  }

  async getDefaultProfile(): Promise<Profile | undefined> {
    return this.profiles.get("default-profile-id");
  }

  async getSocialLinksByProfileId(profileId: string): Promise<SocialLink[]> {
    return Array.from(this.socialLinks.values()).filter(
      (link) => link.profileId === profileId && link.isVisible === "true"
    );
  }

  async createSocialLink(insertSocialLink: InsertSocialLink): Promise<SocialLink> {
    const id = randomUUID();
    const socialLink: SocialLink = { 
      ...insertSocialLink, 
      id,
      isVisible: insertSocialLink.isVisible ?? "true",
    };
    this.socialLinks.set(id, socialLink);
    return socialLink;
  }
}

export const storage = new MemStorage();
