# Social Profile Application

## Overview

This is a modern social profile application built with React and Express.js that displays user profiles with social media links. The application features a clean, responsive design with animated social media cards and supports multiple social platforms like Instagram, Twitter, LinkedIn, GitHub, TikTok, and YouTube. The frontend uses modern UI components from shadcn/ui with Tailwind CSS for styling, while the backend provides a REST API for profile and social link management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the user interface
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight React Router alternative)
- **TanStack Query** for server state management and data fetching
- **Framer Motion** for animations and transitions
- **Tailwind CSS** with shadcn/ui components for styling and UI primitives
- Component structure follows atomic design with reusable UI components in `/client/src/components/ui/`

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** design with endpoints for profiles and social links
- **In-memory storage** implementation with interface for future database integration
- **Middleware** for request logging and error handling
- **Static file serving** for production builds

### Data Storage Solutions
- **Drizzle ORM** configured for PostgreSQL with schema definitions
- **Neon Database** serverless PostgreSQL integration ready
- **In-memory storage** currently used for development with default seed data
- Database schema includes profiles and social_links tables with proper relationships

### Authentication and Authorization
- Currently no authentication system implemented
- Session management setup available with `connect-pg-simple` for PostgreSQL sessions
- Public API endpoints for profile data access

### External Dependencies
- **Neon Database** - Serverless PostgreSQL database platform
- **Vercel/Replit deployment** - Platform-specific plugins and configurations
- **Google Fonts** - External font loading for typography
- **Unsplash** - Profile image hosting for demo data
- **Social Platform APIs** - External links to Instagram, Twitter, LinkedIn, GitHub, TikTok, YouTube

Key architectural decisions include using Drizzle ORM for type-safe database operations, implementing a storage interface pattern for easy database switching, and choosing lightweight alternatives like Wouter for routing to keep the bundle size small. The application follows a clean separation between client and server code with shared TypeScript types.