import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Camera, Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ProfilePictureUploadProps {
  currentImageUrl: string;
  onUploadSuccess?: (newImageUrl: string) => void;
}

export default function ProfilePictureUpload({ 
  currentImageUrl, 
  onUploadSuccess 
}: ProfilePictureUploadProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('profilePicture', file);
      
      const response = await fetch('/api/profile/picture', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      const data = await response.json();
      return data;
    },
    onSuccess: (data) => {
      setPreviewUrl(null);
      onUploadSuccess?.(data.profileImageUrl);
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Success!",
        description: "Profile picture updated successfully",
      });
    },
    onError: (error) => {
      console.error('Upload error:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to update profile picture. Please try again.",
        variant: "destructive",
      });
      setPreviewUrl(null);
    }
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Upload immediately
    uploadMutation.mutate(file);
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const displayImageUrl = previewUrl || currentImageUrl;

  return (
    <div className="relative inline-block">
      <div className="gradient-border inline-block">
        <img
          src={displayImageUrl}
          alt="Profile Picture"
          className="profile-image w-24 h-24 rounded-full object-cover"
          data-testid="img-profile"
        />
      </div>
      
      {/* Upload overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Button
          onClick={handleUploadClick}
          disabled={uploadMutation.isPending}
          variant="secondary"
          size="sm"
          className="opacity-0 hover:opacity-100 transition-opacity duration-200 bg-black/70 text-white hover:bg-black/80 border-0 rounded-full w-8 h-8 p-0"
          data-testid="button-upload-picture"
        >
          {uploadMutation.isPending ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Camera className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
        data-testid="input-file-upload"
      />

      {/* Upload indicator */}
      {uploadMutation.isPending && (
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
          <div className="flex items-center space-x-1 bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
            <Upload className="w-3 h-3" />
            <span>Uploading...</span>
          </div>
        </div>
      )}
    </div>
  );
}