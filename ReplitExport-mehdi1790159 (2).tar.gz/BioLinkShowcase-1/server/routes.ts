import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import multer from "multer";
import sharp from "sharp";
import path from "path";
import { promises as fs } from "fs";
import { randomUUID } from "crypto";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept only image files
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded images statically
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  // Get default profile with social links
  app.get("/api/profile", async (req, res) => {
    try {
      const profile = await storage.getDefaultProfile();
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      const socialLinks = await storage.getSocialLinksByProfileId(profile.id);
      
      res.json({
        profile,
        socialLinks,
      });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get profile by ID
  app.get("/api/profile/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const profile = await storage.getProfile(id);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      const socialLinks = await storage.getSocialLinksByProfileId(profile.id);
      
      res.json({
        profile,
        socialLinks,
      });
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Upload profile picture
  app.post("/api/profile/picture", upload.single('profilePicture'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Get the default profile (for now, we'll just update the default profile)
      const profile = await storage.getDefaultProfile();
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      // Generate unique filename
      const filename = `profile-${profile.id}-${randomUUID()}.jpg`;
      const filepath = path.join(process.cwd(), 'uploads', 'profile-pictures', filename);

      // Process and resize image using sharp
      await sharp(req.file.buffer)
        .resize(300, 300, { 
          fit: 'cover',
          position: 'center'
        })
        .jpeg({ quality: 90 })
        .toFile(filepath);

      // Update profile with new image URL
      const imageUrl = `/uploads/profile-pictures/${filename}`;
      const updatedProfile = await storage.updateProfile(profile.id, {
        profileImageUrl: imageUrl
      });

      res.json({ 
        message: "Profile picture updated successfully",
        profileImageUrl: imageUrl,
        profile: updatedProfile
      });
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
