import { type Profile, type InsertProfile, type SocialLink, type InsertSocialLink, profiles, socialLinks } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Profile operations
  getProfile(id: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile>;
  getDefaultProfile(): Promise<Profile | undefined>;
  
  // Social links operations
  getSocialLinksByProfileId(profileId: string): Promise<SocialLink[]>;
  createSocialLink(socialLink: InsertSocialLink): Promise<SocialLink>;
}

export class DatabaseStorage implements IStorage {
  async getProfile(id: string): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.id, id));
    return profile || undefined;
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const [profile] = await db
      .insert(profiles)
      .values({
        ...insertProfile,
        followers: insertProfile.followers ?? 0,
        following: insertProfile.following ?? 0,
        posts: insertProfile.posts ?? 0,
      })
      .returning();
    return profile;
  }

  async updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile> {
    const [profile] = await db
      .update(profiles)
      .set(updates)
      .where(eq(profiles.id, id))
      .returning();
    return profile;
  }

  async getDefaultProfile(): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).limit(1);
    return profile || undefined;
  }

  async getSocialLinksByProfileId(profileId: string): Promise<SocialLink[]> {
    const links = await db
      .select()
      .from(socialLinks)
      .where(eq(socialLinks.profileId, profileId));
    
    return links.filter(link => link.isVisible === "true");
  }

  async createSocialLink(insertSocialLink: InsertSocialLink): Promise<SocialLink> {
    const [socialLink] = await db
      .insert(socialLinks)
      .values({
        ...insertSocialLink,
        isVisible: insertSocialLink.isVisible ?? "true",
      })
      .returning();
    return socialLink;
  }

  // Initialize default data if database is empty
  async initializeDefaultData(): Promise<void> {
    const existingProfile = await this.getDefaultProfile();
    if (existingProfile) return;

    // Create default profile
    const defaultProfile = await this.createProfile({
      name: "Alex Johnson",
      title: "Creative Designer & Developer",
      bio: "Passionate about creating beautiful digital experiences. Follow me on my creative journey! ✨",
      profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=300",
      email: "alex@example.com",
      followers: 12500,
      following: 892,
      posts: 156,
    });

    // Create default social links
    const defaultSocialLinksData = [
      {
        platform: "instagram",
        url: "https://instagram.com/alexjohnson_creative",
        username: "@alexjohnson_creative",
      },
      {
        platform: "twitter",
        url: "https://twitter.com/alexjcreative",
        username: "@alexjcreative",
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/alexjohnson",
        username: "Alex Johnson",
      },
      {
        platform: "github",
        url: "https://github.com/alexjohnson-dev",
        username: "alexjohnson-dev",
      },
      {
        platform: "tiktok",
        url: "https://tiktok.com/@alexcreates",
        username: "@alexcreates",
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/alexjohnsoncreative",
        username: "Alex Johnson Creative",
      },
    ];

    for (const linkData of defaultSocialLinksData) {
      await this.createSocialLink({
        ...linkData,
        profileId: defaultProfile.id,
        isVisible: "true",
      });
    }
  }
}

export const storage = new DatabaseStorage();
