import React, { useState, useEffect } from 'react';
import { Trash2, Edit, Plus, User, Calendar, DollarSign, Download, Upload, Save } from 'lucide-react';

export default function DebtCreditorManager() {
  const [records, setRecords] = useState([]);
  const [autoSave, setAutoSave] = useState(true);
  const [lastSaved, setLastSaved] = useState(null);
  const [form, setForm] = useState({
    name: '',
    type: 'debtor',
    amount: '',
    date: '',
    description: '',
    phone: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [filter, setFilter] = useState('all');

  // بارگذاری اطلاعات هنگام شروع
  useEffect(() => {
    const savedData = localStorage.getItem('debtCreditorData');
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        setRecords(parsedData);
        setLastSaved(new Date());
      } catch (error) {
        console.error('خطا در بارگذاری اطلاعات:', error);
      }
    }
  }, []);

  // ذخیره خودکار هنگام تغییر اطلاعات
  useEffect(() => {
    if (records.length > 0 && autoSave) {
      localStorage.setItem('debtCreditorData', JSON.stringify(records));
      setLastSaved(new Date());
    }
  }, [records, autoSave]);

  // ذخیره دستی
  const handleManualSave = () => {
    localStorage.setItem('debtCreditorData', JSON.stringify(records));
    setLastSaved(new Date());
  };

  // پاک کردن همه اطلاعات
  const handleClearAll = () => {
    if (confirm('آیا مطمئن هستید که می‌خواهید همه اطلاعات را پاک کنید؟')) {
      setRecords([]);
      localStorage.removeItem('debtCreditorData');
      setLastSaved(null);
    }
  };

  // دانلود فایل بک‌آپ
  const handleExportData = () => {
    const dataStr = JSON.stringify(records, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `debt-creditor-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // آپلود فایل بک‌آپ
  const handleImportData = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedData = JSON.parse(e.target.result);
          if (Array.isArray(importedData)) {
            if (confirm('آیا می‌خواهید اطلاعات فعلی را با اطلاعات آپلود شده جایگزین کنید؟')) {
              setRecords(importedData);
              setLastSaved(new Date());
            }
          } else {
            alert('فرمت فایل نامعتبر است');
          }
        } catch (error) {
          alert('خطا در خواندن فایل: ' + error.message);
        }
      };
      reader.readAsText(file);
    }
    event.target.value = '';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.amount) return;

    const newRecord = {
      id: editingId || Date.now(),
      ...form,
      amount: parseFloat(form.amount),
      date: form.date || new Date().toISOString().split('T')[0]
    };

    if (editingId) {
      setRecords(records.map(r => r.id === editingId ? newRecord : r));
      setEditingId(null);
    } else {
      setRecords([...records, newRecord]);
    }

    setForm({ name: '', type: 'debtor', amount: '', date: '', description: '', phone: '' });
  };

  const handleEdit = (record) => {
    setForm({
      name: record.name,
      type: record.type,
      amount: record.amount.toString(),
      date: record.date,
      description: record.description,
      phone: record.phone
    });
    setEditingId(record.id);
  };

  const handleDelete = (id) => {
    setRecords(records.filter(r => r.id !== id));
  };

  const filteredRecords = records.filter(record => {
    if (filter === 'all') return true;
    return record.type === filter;
  });

  const totalDebtors = records.filter(r => r.type === 'debtor').reduce((sum, r) => sum + r.amount, 0);
  const totalCreditors = records.filter(r => r.type === 'creditor').reduce((sum, r) => sum + r.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm p-4 mb-4">
        <h1 className="text-2xl font-bold text-center text-gray-800 mb-4">
          مدیریت بدهکاران و طلبکاران
        </h1>

        {/* کنترل‌های ذخیره و بک‌آپ */}
        <div className="bg-gray-50 rounded-lg p-3 mb-4">
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={autoSave}
                  onChange={(e) => setAutoSave(e.target.checked)}
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">ذخیره خودکار</span>
              </label>
              
              <button
                onClick={handleManualSave}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm flex items-center gap-1"
              >
                <Save className="w-4 h-4" />
                ذخیره
              </button>
            </div>

            {lastSaved && (
              <div className="text-xs text-gray-600 text-center">
                آخرین ذخیره: {lastSaved.toLocaleTimeString('fa-IR')}
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleExportData}
                className="px-2 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-xs flex items-center justify-center gap-1"
                disabled={records.length === 0}
              >
                <Download className="w-3 h-3" />
                دانلود
              </button>
              
              <label className="px-2 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-xs flex items-center justify-center gap-1 cursor-pointer">
                <Upload className="w-3 h-3" />
                آپلود
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportData}
                  className="hidden"
                />
              </label>
              
              <button
                onClick={handleClearAll}
                className="px-2 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-xs"
                disabled={records.length === 0}
              >
                پاک همه
              </button>
            </div>
          </div>
        </div>

        {/* خلاصه مالی */}
        <div className="grid grid-cols-1 gap-3 mb-4">
          <div className="bg-red-100 p-3 rounded-lg text-center">
            <div className="text-red-600 font-bold text-sm">کل بدهکاران</div>
            <div className="text-lg font-bold text-red-700">{totalDebtors.toLocaleString()} تومان</div>
          </div>
          <div className="bg-green-100 p-3 rounded-lg text-center">
            <div className="text-green-600 font-bold text-sm">کل طلبکاران</div>
            <div className="text-lg font-bold text-green-700">{totalCreditors.toLocaleString()} تومان</div>
          </div>
          <div className="bg-blue-100 p-3 rounded-lg text-center">
            <div className="text-blue-600 font-bold text-sm">تراز</div>
            <div className={`text-lg font-bold ${totalDebtors - totalCreditors >= 0 ? 'text-green-700' : 'text-red-700'}`}>
              {(totalDebtors - totalCreditors).toLocaleString()} تومان
            </div>
          </div>
        </div>

        {/* فرم */}
        <form onSubmit={handleSubmit} className="space-y-3 mb-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({...form, name: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                placeholder="نام شخص"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نوع</label>
              <select
                value={form.type}
                onChange={(e) => setForm({...form, type: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              >
                <option value="debtor">بدهکار</option>
                <option value="creditor">طلبکار</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">مبلغ (تومان)</label>
            <input
              type="number"
              value={form.amount}
              onChange={(e) => setForm({...form, amount: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              placeholder="مبلغ"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({...form, date: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تماس</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({...form, phone: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                placeholder="شماره تماس"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">توضیحات</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({...form, description: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              placeholder="توضیحات اضافی"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            {editingId ? 'بروزرسانی' : 'اضافه کردن'}
          </button>
        </form>

        {/* فیلتر */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-2 rounded-lg font-medium text-sm flex-1 ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'}`}
          >
            همه ({records.length})
          </button>
          <button
            onClick={() => setFilter('debtor')}
            className={`px-3 py-2 rounded-lg font-medium text-sm flex-1 ${filter === 'debtor' ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700'}`}
          >
            بدهکار ({records.filter(r => r.type === 'debtor').length})
          </button>
          <button
            onClick={() => setFilter('creditor')}
            className={`px-3 py-2 rounded-lg font-medium text-sm flex-1 ${filter === 'creditor' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'}`}
          >
            طلبکار ({records.filter(r => r.type === 'creditor').length})
          </button>
        </div>
      </div>

      {/* لیست رکوردها */}
      <div className="px-4 pb-4 space-y-3">
        {filteredRecords.length === 0 ? (
          <div className="text-center py-8 text-gray-500 bg-white rounded-lg mx-4">
            هنوز هیچ رکوردی ثبت نشده است
          </div>
        ) : (
          filteredRecords.map((record) => (
            <div
              key={record.id}
              className={`bg-white rounded-lg shadow-md p-4 border-r-4 ${
                record.type === 'debtor' ? 'border-red-500' : 'border-green-500'
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-gray-600" />
                    <h3 className="text-lg font-bold text-gray-800">{record.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      record.type === 'debtor' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {record.type === 'debtor' ? 'بدهکار' : 'طلبکار'}
                    </span>
                  </div>
                  
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      <span className="font-medium text-base">{record.amount.toLocaleString()} تومان</span>
                    </div>
                    
                    {record.date && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(record.date).toLocaleDateString('fa-IR')}</span>
                      </div>
                    )}
                    
                    {record.phone && (
                      <div className="flex items-center gap-2">
                        <span>📞</span>
                        <a href={`tel:${record.phone}`} className="text-blue-600">{record.phone}</a>
                      </div>
                    )}
                    
                    {record.description && (
                      <div className="flex items-center gap-2">
                        <span>📝</span>
                        <span className="text-xs">{record.description}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleEdit(record)}
                    className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors"
                    title="ویرایش"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(record.id)}
                    className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                    title="حذف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}